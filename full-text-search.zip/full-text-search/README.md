# full-text-search
Implement full text search by source: ./data.json

### Build and Run
```
./gradlew run
```

Open: http://localhost:8080 for search

## Improve
- logging;
- JSON source reading as some Data provider or source;
- exception handling
- pagination
- design :)